"""
db.py - SQLite storage for PokeQuant.

This is the only module that talks to the database. Everything else (scanner,
app, data_generator) goes through the functions below, so swapping SQLite for
Postgres or a real price feed later only means changing this file.

Tables
  cards   one row per card (id slug, name, set, rarity, ...)
  prices  one row per card per day (price, volume, PSA 10 multiplier, catalyst flag)
"""
import os
import sqlite3
import math
from contextlib import contextmanager

import pandas as pd

import grading

DB_PATH = os.environ.get(
    "POKEQUANT_DB",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "pokequant.db"),
)

CARDS_DDL = """
CREATE TABLE IF NOT EXISTS cards (
    card_id     TEXT PRIMARY KEY,          -- slug, e.g. 'charizard_holo' (matches reference image filename)
    name        TEXT NOT NULL,
    set_name    TEXT NOT NULL,
    rarity      TEXT NOT NULL,
    base_price  REAL NOT NULL,             -- starting price used when generating mock history
    api_id      TEXT,                      -- pokemontcg.io id
    variant     TEXT,
    image_url   TEXT                       -- card artwork URL, saved when the card is added
);
"""

PRICES_DDL = """
CREATE TABLE IF NOT EXISTS prices (
    card_id          TEXT NOT NULL REFERENCES cards(card_id) ON DELETE CASCADE,
    price_date       TEXT NOT NULL,        -- ISO date
    market_price     REAL NOT NULL,
    volume           INTEGER,              -- NULL when the source doesn't provide it
    psa10_multiplier REAL,                 -- NULL when the source doesn't provide it
    catalyst_flag    INTEGER NOT NULL DEFAULT 0,
    source           TEXT NOT NULL DEFAULT 'mock',   -- 'mock' | 'tcgplayer' | 'csv' | 'manual'
    grade            TEXT NOT NULL DEFAULT 'Raw',    -- 'Raw' (ungraded) or e.g. 'PSA 10' (see grading.py)
    PRIMARY KEY (card_id, price_date, grade)
);
"""

SCHEMA = CARDS_DDL + PRICES_DDL + """
CREATE INDEX IF NOT EXISTS idx_prices_card_grade_date ON prices(card_id, grade, price_date);
"""


def _columns(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]


def _migrate(conn):
    """Upgrade a database created by an older version (adds api_id / variant / image_url / source /
    grade columns). Existing prices become 'Raw'. Safe to run repeatedly; keeps all data."""
    cards_cols = _columns(conn, "cards")
    if cards_cols and "api_id" not in cards_cols:
        conn.execute("ALTER TABLE cards ADD COLUMN api_id TEXT")
    if cards_cols and "variant" not in cards_cols:
        conn.execute("ALTER TABLE cards ADD COLUMN variant TEXT")
    if cards_cols and "image_url" not in cards_cols:
        conn.execute("ALTER TABLE cards ADD COLUMN image_url TEXT")
    price_cols = _columns(conn, "prices")
    if price_cols and not {"source", "grade"} <= set(price_cols):
        conn.execute("ALTER TABLE prices RENAME TO prices_old")
        conn.executescript(PRICES_DDL)
        source_expr = "source" if "source" in price_cols else "'mock'"
        grade_expr = "grade" if "grade" in price_cols else "'Raw'"   # every pre-grading row is ungraded
        conn.execute(
            f"""INSERT INTO prices (card_id, price_date, market_price, volume, psa10_multiplier,
                                    catalyst_flag, source, grade)
                SELECT card_id, price_date, market_price, volume, psa10_multiplier, catalyst_flag,
                       {source_expr}, {grade_expr}
                FROM prices_old""")
        conn.execute("DROP TABLE prices_old")


_checked_paths = set()


def _ensure_schema():
    """Create / upgrade the tables the first time each database file is opened in this process,
    so every entry point (app, scripts, importers) always sees the current schema."""
    if DB_PATH in _checked_paths:
        return
    conn = sqlite3.connect(DB_PATH)
    try:
        _migrate(conn)
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()
    _checked_paths.add(DB_PATH)


@contextmanager
def connect():
    _ensure_schema()
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create tables if they don't exist yet (and upgrade an older database file)."""
    with connect():
        pass


def initialize_database():
    """Seed only a missing database; existing empty databases belong to the user."""
    is_new = not os.path.exists(DB_PATH)
    init_db()
    if is_new:
        from data_generator import seed_database
        seed_database(reset=False)


def reset_db():
    """Delete the database file and recreate empty tables."""
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    _checked_paths.discard(DB_PATH)
    init_db()


def has_data() -> bool:
    if not os.path.exists(DB_PATH):
        return False
    with connect() as conn:
        n_cards = conn.execute("SELECT COUNT(*) FROM cards").fetchone()[0]
        n_prices = conn.execute("SELECT COUNT(*) FROM prices").fetchone()[0]
    return n_cards > 0 and n_prices > 0


# ----------------------------------------------------------------- writes ----
def upsert_card(card_id, name, set_name, rarity, base_price, api_id=None, variant=None, image_url=None):
    with connect() as conn:
        conn.execute(
            """INSERT INTO cards (card_id, name, set_name, rarity, base_price, api_id, variant, image_url)
               VALUES (?,?,?,?,?,?,?,?)
               ON CONFLICT(card_id) DO UPDATE SET
                 name=excluded.name, set_name=excluded.set_name,
                 rarity=excluded.rarity, base_price=excluded.base_price,
                 api_id=COALESCE(excluded.api_id, cards.api_id),
                 variant=COALESCE(excluded.variant, cards.variant),
                 image_url=COALESCE(excluded.image_url, cards.image_url)""",
            (card_id, name, set_name, rarity, float(base_price), api_id, variant, image_url),
        )


def set_card_image(card_id, image_url):
    """Remember a card's artwork URL so it never has to be looked up over the network again."""
    with connect() as conn:
        conn.execute("UPDATE cards SET image_url=? WHERE card_id=?", (image_url or None, card_id))


def link_real_card(card_id, api_id, name, set_name, rarity, variant=None, image_url=None):
    """Turn an existing (mock) card into a real-price card: update its details, store its
    pokemontcg.io id and delete its MOCK price rows so fake and real data never mix."""
    with connect() as conn:
        existing = conn.execute("SELECT api_id, variant, image_url FROM cards WHERE card_id=?", (card_id,)).fetchone()
        if existing is None:
            raise ValueError("Card not found.")
        has_real = conn.execute("SELECT 1 FROM prices WHERE card_id=? AND source!='mock' LIMIT 1", (card_id,)).fetchone()
        if has_real and (existing[0] != api_id or existing[1] != variant):
            raise ValueError("This card has real history for a different or unconfirmed identity/variant. Save as a new card instead.")
        # Artwork follows the card's identity: keep the stored image only if this is the same API card;
        # otherwise (a demo card being repurposed) the old picture would be wrong, so drop it.
        image_url = image_url or (existing[2] if existing[0] == api_id else None)
        conn.execute("UPDATE cards SET api_id=?, name=?, set_name=?, rarity=?, variant=?, image_url=? WHERE card_id=?",
                     (api_id, name, set_name, rarity, variant, image_url, card_id))
        conn.execute("DELETE FROM prices WHERE card_id=? AND source='mock'", (card_id,))


def _num(x):
    return None if x is None or pd.isna(x) else float(x)


def replace_price_history(card_id, df: pd.DataFrame, grade=grading.RAW):
    """Replace one grade's whole MOCK-style price history with `df` (index = Date, columns as
    produced by MockDataGenerator). Other grades of the card are left alone."""
    grade = grading.normalize_grade(grade)
    rows = [
        (card_id, ts.strftime("%Y-%m-%d"), float(r["Market Price ($)"]),
         int(r["Daily Trading Volume"]), _num(r["PSA 10 Multiplier"]), int(bool(r["Catalyst Flag"])), "mock", grade)
        for ts, r in df.iterrows()
    ]
    with connect() as conn:
        conn.execute("DELETE FROM prices WHERE card_id = ? AND grade = ?", (card_id, grade))
        conn.executemany(
            """INSERT INTO prices (card_id, price_date, market_price, volume, psa10_multiplier,
                                   catalyst_flag, source, grade) VALUES (?,?,?,?,?,?,?,?)""", rows)


def add_price(card_id, price_date, market_price, volume=None, psa10_multiplier=None,
              catalyst_flag=False, source="manual", grade=grading.RAW):
    """Insert/update a single day's observation. One row per card per day: recording again on
    the same date (and grade) overwrites that day. `source` tags where the number came from."""
    grade = grading.normalize_grade(grade)
    with connect() as conn:
        conn.execute(
            """INSERT INTO prices (card_id, price_date, market_price, volume, psa10_multiplier,
                                   catalyst_flag, source, grade)
               VALUES (?,?,?,?,?,?,?,?)
               ON CONFLICT(card_id, price_date, grade) DO UPDATE SET
                 market_price=excluded.market_price, volume=excluded.volume,
                 psa10_multiplier=excluded.psa10_multiplier, catalyst_flag=excluded.catalyst_flag,
                 source=excluded.source""",
            (card_id, str(price_date)[:10], float(market_price),
             None if volume is None else int(volume),
             None if psa10_multiplier is None else float(psa10_multiplier),
             int(bool(catalyst_flag)), source, grade),
        )


def add_prices_bulk(card_id, rows, source="csv", replace_mock=False, grade=grading.RAW):
    """rows: iterable of (date, price, volume_or_None) for ONE grade. Upserts all in one transaction.
    replace_mock deletes only this grade's made-up rows first."""
    grade = grading.normalize_grade(grade)
    data = [(card_id, str(d)[:10], float(p), None if v is None else int(v), source, grade) for d, p, v in rows]
    if not data:
        raise ValueError("No prices to import.")
    for _, day, price, volume, _, _ in data:
        pd.Timestamp(day)
        if not math.isfinite(price) or price <= 0 or (volume is not None and not 0 <= volume < 2**63):
            raise ValueError("Prices must be finite and positive; volumes must be nonnegative SQLite integers.")
    with connect() as conn:
        removed = conn.execute("DELETE FROM prices WHERE card_id=? AND source='mock' AND grade=?",
                               (card_id, grade)).rowcount if replace_mock else 0
        conn.executemany(
            """INSERT INTO prices (card_id, price_date, market_price, volume, catalyst_flag, source, grade)
               VALUES (?,?,?,?,0,?,?)
               ON CONFLICT(card_id, price_date, grade) DO UPDATE SET
                 market_price=excluded.market_price, volume=excluded.volume, source=excluded.source""",
            data)
    return (len(data), removed) if replace_mock else len(data)


def delete_price_rows(card_id, source=None, grade=None):
    """Delete a card's price rows, optionally only one source and/or one grade. Returns rows deleted."""
    sql, params = "DELETE FROM prices WHERE card_id=?", [card_id]
    if source:
        sql += " AND source=?"
        params.append(source)
    if grade:
        sql += " AND grade=?"
        params.append(grading.normalize_grade(grade))
    with connect() as conn:
        return conn.execute(sql, params).rowcount


def delete_card(card_id):
    """Permanently remove a card and ALL of its price history (every grade).
    Returns {"cards": 0 or 1, "prices": rows_deleted}. Safe to call for a card that doesn't exist."""
    with connect() as conn:
        prices = conn.execute("DELETE FROM prices WHERE card_id=?", (card_id,)).rowcount
        cards = conn.execute("DELETE FROM cards WHERE card_id=?", (card_id,)).rowcount
    return {"cards": cards, "prices": prices}


# ------------------------------------------------------------------ reads ----
def get_card(card_id):
    """Return a dict {card_id, name, rarity, set, api_id, variant, image_url} or None if the card isn't in the database."""
    if not os.path.exists(DB_PATH):
        return None
    init_db()
    with connect() as conn:
        row = conn.execute(
            "SELECT card_id, name, rarity, set_name, api_id, variant, image_url FROM cards WHERE card_id = ?", (card_id,)
        ).fetchone()
    if row is None:
        return None
    return {"card_id": row[0], "name": row[1], "rarity": row[2], "set": row[3], "api_id": row[4],
            "variant": row[5], "image_url": row[6]}


def list_cards() -> pd.DataFrame:
    if not os.path.exists(DB_PATH):
        return pd.DataFrame(columns=["card_id", "name", "set_name", "rarity", "base_price", "api_id", "variant", "image_url"])
    init_db()
    with connect() as conn:
        return pd.read_sql_query(
            "SELECT card_id, name, set_name, rarity, base_price, api_id, variant, image_url FROM cards ORDER BY name", conn)


def get_source_summary() -> pd.DataFrame:
    """One row per card AND grade: price points, source(s) and the latest price.
    A card with no prices at all appears once with a blank grade."""
    if not os.path.exists(DB_PATH):
        return pd.DataFrame()
    with connect() as conn:
        df = pd.read_sql_query(
            """SELECT c.card_id, c.name, c.api_id, p.grade,
                      COUNT(p.price_date) AS points,
                      GROUP_CONCAT(DISTINCT p.source) AS sources,
                      MIN(p.price_date) AS first_date, MAX(p.price_date) AS last_date,
                      (SELECT market_price FROM prices WHERE card_id=c.card_id AND grade IS p.grade
                       ORDER BY price_date DESC LIMIT 1) AS last_price
               FROM cards c LEFT JOIN prices p ON p.card_id = c.card_id
               GROUP BY c.card_id, p.grade""", conn)
    df["_g"] = df["grade"].map(lambda g: grading.sort_key(g) if isinstance(g, str) else -1)
    return df.sort_values(["name", "card_id", "_g"]).drop(columns="_g").reset_index(drop=True)


def get_grade_summary(card_id) -> pd.DataFrame:
    """The grades this card has prices for, in display order (Raw first):
    grade, points, sources, first_date, last_date, last_price."""
    cols = ["grade", "points", "sources", "first_date", "last_date", "last_price"]
    if not os.path.exists(DB_PATH):
        return pd.DataFrame(columns=cols)
    with connect() as conn:
        df = pd.read_sql_query(
            """SELECT p.grade, COUNT(*) AS points, GROUP_CONCAT(DISTINCT p.source) AS sources,
                      MIN(p.price_date) AS first_date, MAX(p.price_date) AS last_date,
                      (SELECT market_price FROM prices q WHERE q.card_id=p.card_id AND q.grade=p.grade
                       ORDER BY q.price_date DESC LIMIT 1) AS last_price
               FROM prices p WHERE p.card_id = ? GROUP BY p.grade""", conn, params=(card_id,))
    if df.empty:
        return pd.DataFrame(columns=cols)
    return df.sort_values("grade", key=lambda col: col.map(grading.sort_key)).reset_index(drop=True)


def get_grades_by_card() -> dict:
    """{card_id: [grades in display order]} for every card that has prices."""
    if not os.path.exists(DB_PATH):
        return {}
    with connect() as conn:
        rows = conn.execute("SELECT DISTINCT card_id, grade FROM prices").fetchall()
    out = {}
    for card_id, grade in rows:
        out.setdefault(card_id, []).append(grade)
    return {k: sorted(v, key=grading.sort_key) for k, v in out.items()}


def get_price_history(card_id, days=None, grade=grading.RAW) -> pd.DataFrame:
    """Price history in the exact shape the model/app already expect:
    index 'Date'; columns 'Market Price ($)', 'Daily Trading Volume',
    'PSA 10 Multiplier', 'Catalyst Flag'. Empty frame if the card has no data.
    `grade` picks which grade's prices ('Raw' by default). `days` keeps only the most recent N rows."""
    grade = grading.normalize_grade(grade)
    if not os.path.exists(DB_PATH):
        return pd.DataFrame()
    init_db()
    with connect() as conn:
        df = pd.read_sql_query(
            """SELECT price_date AS Date, market_price AS "Market Price ($)",
                      volume AS "Daily Trading Volume", psa10_multiplier AS "PSA 10 Multiplier",
                      catalyst_flag AS "Catalyst Flag"
               FROM prices WHERE card_id = ? AND grade = ? ORDER BY price_date""",
            conn, params=(card_id, grade))
    if df.empty:
        return df
    df["Date"] = pd.to_datetime(df["Date"])
    df["Catalyst Flag"] = df["Catalyst Flag"].astype(bool)
    df = df.set_index("Date")
    return df.iloc[-days:] if days else df


def get_card_sources(card_id, grade=None):
    """(number_of_price_points, set_of_sources) for one card, e.g. (91, {'csv', 'tcgplayer'}).
    Pass `grade` to count only that grade's prices; otherwise all grades are counted."""
    if not os.path.exists(DB_PATH):
        return 0, set()
    where, params = "card_id=?", [card_id]
    if grade:
        where += " AND grade=?"
        params.append(grading.normalize_grade(grade))
    with connect() as conn:
        n = conn.execute(f"SELECT COUNT(*) FROM prices WHERE {where}", params).fetchone()[0]
        src = {r[0] for r in conn.execute(f"SELECT DISTINCT source FROM prices WHERE {where}", params)}
    return n, src
