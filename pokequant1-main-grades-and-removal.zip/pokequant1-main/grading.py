"""
grading.py - the grading levels a card can be tracked at.

A card (e.g. Charizard, Base Set) can have a separate price history for each grade:
"Raw" (ungraded) plus professionally graded copies such as "PSA 10" or "BGS 9.5".
Grades are stored as plain text in the prices table; this module is the one place that
defines which grades exist, how they are ordered, and how to compare them.
"""
import pandas as pd

RAW = "Raw"

# Display order: Raw first, then each grading company from best to worst grade.
GRADES = [
    RAW,
    "PSA 10", "PSA 9", "PSA 8", "PSA 7",
    "BGS 10", "BGS 9.5", "BGS 9",
    "CGC 10", "CGC 9.5", "CGC 9",
]

# Rough price multiples vs Raw, used ONLY to generate made-up demo histories.
MOCK_MULTIPLIERS = {"PSA 10": 5.0, "PSA 9": 2.2, "PSA 8": 1.5, "BGS 9.5": 3.6, "CGC 10": 4.2}

_ALIASES = {"ungraded": RAW, "raw": RAW, "nm": RAW}


def normalize_grade(grade):
    """Return the canonical grade name ('psa 10' -> 'PSA 10', 'ungraded' -> 'Raw') or raise ValueError."""
    text = " ".join(str(grade or "").split())
    if text.lower() in _ALIASES:
        return _ALIASES[text.lower()]
    for g in GRADES:
        if g.lower() == text.lower():
            return g
    raise ValueError(f"Unknown grade '{grade}'. Choose one of: {', '.join(GRADES)}.")


def sort_key(grade):
    return GRADES.index(grade) if grade in GRADES else len(GRADES)


def add_premium(summary):
    """Add a 'premium' column to a per-grade summary (needs 'grade' and 'last_price'):
    each grade's latest price divided by the Raw latest price (None when there is no Raw price)."""
    out = summary.copy()
    raw = out.loc[out["grade"] == RAW, "last_price"]
    raw_price = float(raw.iloc[0]) if len(raw) and pd.notna(raw.iloc[0]) and raw.iloc[0] > 0 else None
    out["premium"] = out["last_price"] / raw_price if raw_price else float("nan")
    return out
