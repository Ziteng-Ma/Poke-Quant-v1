import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from unittest.mock import Mock, patch

import numpy as np
import pandas as pd

import data_generator
import db
import grading
import price_sources as ps
from math_model import VolatilityForecaster
import requests
from card_images import ArtworkLookupError, find_card_image


class StorageTests(unittest.TestCase):
    def setUp(self):
        # Keep all temporary database writes and cleanup inside the workspace.
        self.temp = tempfile.TemporaryDirectory(dir=os.path.dirname(__file__))
        self.path_patch = patch.object(db, "DB_PATH", os.path.join(self.temp.name, "test.db"))
        self.path_patch.start()
        db.init_db()
        db.upsert_card("test", "Test", "Set", "Rare", 10)

    def tearDown(self):
        db._checked_paths.discard(db.DB_PATH)
        self.path_patch.stop()
        self.temp.cleanup()

    def test_existing_price_less_database_is_preserved(self):
        db.initialize_database()
        self.assertEqual(db.list_cards().card_id.tolist(), ["test"])

    def test_missing_database_is_seeded(self):
        with patch.object(db, "DB_PATH", os.path.join(self.temp.name, "new.db")):
            db.initialize_database()
            self.assertEqual(len(db.list_cards()), 12)

    def test_failed_csv_preserves_history(self):
        db.add_price("test", "2026-01-01", 10, source="mock")
        with self.assertRaises(ps.PriceSourceError):
            ps.import_csv("test", pd.DataFrame({"date": ["2026-01-02"], "price": [12], "volume": [np.inf]}))
        self.assertEqual(db.get_card_sources("test"), (1, {"mock"}))

    def test_database_failure_rolls_back_deletion(self):
        db.add_price("test", "2026-01-01", 10, source="mock")
        with db.connect() as conn:
            conn.execute("CREATE TRIGGER fail_import BEFORE INSERT ON prices BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        with self.assertRaises(sqlite3.IntegrityError):
            ps.import_csv("test", pd.DataFrame({"date": ["2026-01-02"], "price": [12]}))
        self.assertEqual(db.get_card_sources("test"), (1, {"mock"}))

    def test_daily_deduplication_and_successful_import(self):
        db.add_price("test", "2026-01-01", 10, source="mock")
        rows = pd.DataFrame({"date": ["2026-01-02 15:00", "2026-01-02 09:00"], "price": [12, 10]})
        self.assertEqual(len(ps.parse_csv(rows)), 1)
        self.assertEqual(ps.import_csv("test", rows), (1, 1))
        self.assertEqual(db.get_price_history("test").iloc[-1, 0], 12)

    @staticmethod
    def api_card():
        return {"id": "base1-4", "name": "Charizard", "set": {"name": "Base Set"}, "tcgplayer": {"prices": {"holofoil": {"market": 100}, "reverseHolofoil": {"market": 20}}}}

    def test_variants_have_separate_ids_and_refresh_prices(self):
        card = self.api_card()
        holo, _, _ = ps.save_card_with_price(card, "holofoil")
        reverse, _, _ = ps.save_card_with_price(card, "reverseHolofoil")
        self.assertNotEqual(holo, reverse)
        result = ps.refresh_tracked_cards(Mock(get_card=Mock(return_value=card)))
        self.assertTrue(result.Status.eq("ok").all())
        self.assertEqual(db.get_price_history(reverse).iloc[-1, 0], 20)
        del card["tcgplayer"]["prices"]["reverseHolofoil"]
        self.assertIsNone(ps.extract_price(card, "reverseHolofoil")[1])

    def test_legacy_refresh_skips_unconfirmed_variant(self):
        db.upsert_card("legacy", "Test", "Set", "Rare", 10, api_id="base1-4")
        client = Mock()
        result = ps.refresh_tracked_cards(client)
        self.assertIn("Legacy", result.iloc[0].Status)
        client.get_card.assert_not_called()

    def test_relinking_different_identity_preserves_real_history(self):
        db.add_price("test", "2026-01-01", 10, source="csv")
        with self.assertRaises(ValueError):
            db.link_real_card("test", "base1-4", "Other", "Other", "Rare", "holofoil")
        self.assertEqual(db.get_card("test")["name"], "Test")
        self.assertEqual(db.get_card_sources("test")[0], 1)

    def test_confirmed_relink_preserves_real_and_removes_mock(self):
        db.upsert_card("test", "Test", "Set", "Rare", 10, "base1-4", "holofoil")
        db.add_price("test", "2026-01-01", 10, source="csv")
        db.add_price("test", "2026-01-02", 12, source="mock")
        db.link_real_card("test", "base1-4", "Test", "Set", "Rare", "holofoil")
        self.assertEqual(db.get_card_sources("test"), (1, {"csv"}))

    def test_schema_migration_preserves_legacy_history(self):
        path = os.path.join(self.temp.name, "legacy.db")
        with closing(sqlite3.connect(path)) as conn:
            conn.executescript("CREATE TABLE cards(card_id TEXT PRIMARY KEY,name TEXT,set_name TEXT,rarity TEXT,base_price REAL,api_id TEXT); INSERT INTO cards VALUES('old','Old','Set','Rare',10,'base1-4');")
        with patch.object(db, "DB_PATH", path):
            db.init_db()
            self.assertIsNone(db.get_card("old")["variant"])

    def test_dashboard_renders_analysis(self):
        from streamlit.testing.v1 import AppTest
        db.add_prices_bulk("test", [(d.date().isoformat(), 10 + i * .1, None)
                                   for i, d in enumerate(pd.date_range("2026-01-01", periods=40))])
        with patch("card_images.find_card_image", return_value=None):
            app = AppTest.from_file("app.py").run(timeout=20)
        self.assertEqual(len(app.exception), 0)
        self.assertTrue(any(metric.label == "Recommendation" for metric in app.metric))


class AnalysisTests(unittest.TestCase):
    def test_invalid_csv_prices_are_rejected(self):
        for value in [np.inf, -np.inf, 0, -1]:
            with self.subTest(value=value), self.assertRaises(ps.PriceSourceError):
                ps.parse_csv(pd.DataFrame({"date": ["2026-01-01"], "price": [value]}))

    def test_invalid_volumes_are_rejected(self):
        for value in [np.inf, -1, 1.5, 2**63, "oops"]:
            with self.subTest(value=value), self.assertRaises(ps.PriceSourceError):
                ps.parse_csv(pd.DataFrame({"date": ["2026-01-01"], "price": [10], "volume": [value]}))

    def test_irregular_dates_are_daily_without_mutating_input(self):
        prices = pd.Series([10., 20., 30.], index=pd.date_range("2026-01-01", periods=3, freq="7D"))
        model = VolatilityForecaster(prices)
        self.assertEqual(len(model.prices), 15)
        self.assertEqual(model.calculate_metrics()["momentum_7"], 50)
        self.assertEqual(len(prices), 3)

    def test_flat_prices_have_neutral_confidence(self):
        model = VolatilityForecaster(pd.Series(10., index=pd.date_range("2026-01-01", periods=40)))
        signal = model.get_trading_signal(model.calculate_metrics())
        self.assertEqual((signal["score"], signal["confidence"]), (0, 50))

    def test_forecast_uses_daily_returns_and_simulates_first_date(self):
        prices = pd.Series(10 * np.exp(np.arange(40) * .01), index=pd.date_range("2026-01-01", periods=40))
        model = VolatilityForecaster(prices)
        dates, paths = model.forecast_jump_diffusion()
        self.assertEqual(paths.shape, (50, 30))
        self.assertEqual(dates[0], prices.index[-1] + pd.Timedelta(days=1))
        self.assertAlmostEqual(np.median(paths[:, 0]) / prices.iloc[-1], np.exp(.01))
        self.assertAlmostEqual(np.median(paths[:, -1]) / prices.iloc[-1], np.exp(.30))

    def test_invalid_model_prices_are_rejected(self):
        with self.assertRaises(ValueError):
            VolatilityForecaster(pd.Series([10, np.inf], index=pd.date_range("2026-01-01", periods=2)))


class ArtworkTests(unittest.TestCase):
    @patch("card_images.requests.get")
    def test_demo_artwork_uses_tcgdex_catalog_ids(self, get):
        expected = {
            "dragonite_holo": "https://assets.tcgdex.net/en/base/base3/4/high.webp",
            "gengar_holo": "https://assets.tcgdex.net/en/base/base3/5/high.webp",
            "mew_ex": "https://assets.tcgdex.net/en/sv/sv04.5/216/high.webp",
        }
        for card_id, url in expected.items():
            with self.subTest(card_id=card_id):
                self.assertEqual(find_card_image.__wrapped__("Demo", "Demo", card_id), url)
        get.assert_not_called()

    @patch("card_images.requests.get")
    def test_api_identity_overrides_demo_mapping(self, get):
        get.return_value.json.return_value = {"data": {"images": {"large": "exact.png"}}}
        self.assertEqual(find_card_image.__wrapped__("Test", "Set", "charizard_holo", "other-1"), "exact.png")
        self.assertIn("other-1", get.call_args.args[0])

    @patch("card_images.requests.get")
    def test_name_fallback_matches_set(self, get):
        get.return_value.json.return_value = [
            {"name": "Test", "set": {"name": "Wrong"}, "image": "wrong"},
            {"name": "Test", "set": {"name": "Right"}, "image": "right"},
        ]
        self.assertEqual(find_card_image.__wrapped__("Test", "Right"), "right/high.webp")
        self.assertIsNone(find_card_image.__wrapped__("Test", "Missing"))


class ArtworkBugTests(unittest.TestCase):
    """Cards added from the Real Prices tab used to show "Card artwork unavailable"."""

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=os.path.dirname(__file__))
        self.path_patch = patch.object(db, "DB_PATH", os.path.join(self.temp.name, "art.db"))
        self.path_patch.start()
        db.init_db()
        find_card_image.clear()

    def tearDown(self):
        db._checked_paths.discard(db.DB_PATH)
        self.path_patch.stop()
        self.temp.cleanup()

    @staticmethod
    def api_card(**extra):
        card = {"id": "sv3pt5-199", "name": "Charizard ex", "set": {"name": "151"},
                "images": {"small": "https://img/small.png", "large": "https://img/large.png"},
                "tcgplayer": {"prices": {"holofoil": {"market": 55}}}}
        card.update(extra)
        return card

    def test_artwork_is_saved_when_the_card_is_added(self):
        card_id, _, _ = ps.save_card_with_price(self.api_card(), "holofoil")
        self.assertEqual(db.get_card(card_id)["image_url"], "https://img/large.png")

    def test_small_image_is_used_when_no_large_one_exists(self):
        card_id, _, _ = ps.save_card_with_price(self.api_card(images={"small": "https://img/small.png"}), "holofoil")
        self.assertEqual(db.get_card(card_id)["image_url"], "https://img/small.png")

    def test_card_without_images_still_saves(self):
        card = self.api_card()
        del card["images"]
        card_id, _, _ = ps.save_card_with_price(card, "holofoil")
        self.assertIsNone(db.get_card(card_id)["image_url"])

    def test_resaving_without_an_image_keeps_the_stored_one(self):
        card_id, _, _ = ps.save_card_with_price(self.api_card(), "holofoil")
        card = self.api_card()
        del card["images"]
        ps.save_card_with_price(card, "holofoil")
        self.assertEqual(db.get_card(card_id)["image_url"], "https://img/large.png")

    def test_older_database_gets_the_image_column(self):
        path = os.path.join(self.temp.name, "older.db")
        with closing(sqlite3.connect(path)) as conn:
            conn.executescript("CREATE TABLE cards(card_id TEXT PRIMARY KEY,name TEXT,set_name TEXT,rarity TEXT,"
                               "base_price REAL,api_id TEXT,variant TEXT); INSERT INTO cards VALUES('c','C','S','R',1,'base1-4','holofoil');")
        with patch.object(db, "DB_PATH", path):
            db._checked_paths.discard(path)
            self.assertIsNone(db.get_card("c")["image_url"])
            db.set_card_image("c", "https://img/x.png")
            self.assertEqual(db.get_card("c")["image_url"], "https://img/x.png")

    def test_repurposed_demo_card_drops_its_old_picture(self):
        db.upsert_card("demo", "Demo", "Set", "Rare", 10, image_url="https://img/old-demo.png")
        ps.save_card_with_price(self.api_card(), "holofoil", card_id="demo", link_existing=True)
        self.assertEqual(db.get_card("demo")["image_url"], "https://img/large.png")
        card = self.api_card()
        del card["images"]
        db.upsert_card("demo2", "Demo", "Set", "Rare", 10, image_url="https://img/old-demo.png")
        ps.save_card_with_price(card, "holofoil", card_id="demo2", link_existing=True)
        self.assertIsNone(db.get_card("demo2")["image_url"])   # different card: never keep the wrong picture

    def test_refresh_backfills_missing_artwork(self):
        db.upsert_card("old", "Charizard ex", "151", "Rare", 10, api_id="sv3pt5-199", variant="holofoil")
        db.add_price("old", "2026-01-01", 10, source="tcgplayer")
        ps.refresh_tracked_cards(Mock(get_card=Mock(return_value=self.api_card())))
        self.assertEqual(db.get_card("old")["image_url"], "https://img/large.png")

    # ---- lookup for older rows that have no stored artwork
    @patch("card_images.requests.get")
    def test_timeout_is_an_error_not_a_cached_miss(self, get):
        get.side_effect = requests.exceptions.Timeout()
        with self.assertRaises(ArtworkLookupError):
            find_card_image("Charizard ex", "151", "x", "sv3pt5-199")
        # the service recovers: the next call must really ask again and succeed
        get.side_effect = None
        get.return_value.json.return_value = {"data": {"images": {"large": "https://img/ok.png"}}}
        self.assertEqual(find_card_image("Charizard ex", "151", "x", "sv3pt5-199"), "https://img/ok.png")

    @patch("card_images.requests.get")
    def test_falls_back_to_tcgdex_when_pokemontcg_is_down(self, get):
        down = Mock()
        down.raise_for_status.side_effect = requests.HTTPError(response=Mock(status_code=429))
        tcgdex = Mock()
        tcgdex.json.return_value = {"name": "Charizard", "image": "https://assets.tcgdex.net/en/base/base1/4"}
        get.side_effect = [down, tcgdex]
        self.assertEqual(find_card_image("Charizard", "Base", "x", "base1-4"),
                         "https://assets.tcgdex.net/en/base/base1/4/high.webp")

    @patch("card_images.requests.get")
    def test_fallback_rejects_a_different_card_with_the_same_id(self, get):
        down = Mock()
        down.raise_for_status.side_effect = requests.HTTPError(response=Mock(status_code=500))
        other = Mock()
        other.json.return_value = {"name": "Blastoise", "image": "https://assets.tcgdex.net/en/base/base1/4"}
        get.side_effect = [down, other]
        with self.assertRaises(ArtworkLookupError):          # outage + nothing verified: retry later, show nothing wrong
            find_card_image("Charizard", "Base", "x", "base1-4")

    @patch("card_images.requests.get")
    def test_unknown_card_is_a_cached_definite_miss(self, get):
        missing = Mock()
        missing.raise_for_status.side_effect = requests.HTTPError(response=Mock(status_code=404))
        get.return_value = missing
        self.assertIsNone(find_card_image("Nope", "Nowhere", "x", "zzz-1"))

    @patch("card_images.requests.get")
    def test_pokemontcg_lookup_sends_api_key_when_configured(self, get):
        get.return_value.json.return_value = {"data": {"images": {"large": "https://img/k.png"}}}
        with patch.dict(os.environ, {"POKEMONTCG_API_KEY": "secret"}):
            find_card_image("Charizard ex", "151", "x", "sv3pt5-199")
        self.assertEqual(get.call_args.kwargs["headers"], {"X-Api-Key": "secret"})


class _TempDb(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=os.path.dirname(__file__))
        self.path_patch = patch.object(db, "DB_PATH", os.path.join(self.temp.name, "g.db"))
        self.path_patch.start()
        db.init_db()
        db.upsert_card("a", "Card A", "Set", "Rare", 10)
        db.upsert_card("b", "Card B", "Set", "Rare", 10)

    def tearDown(self):
        db._checked_paths.discard(db.DB_PATH)
        self.path_patch.stop()
        self.temp.cleanup()


class GradingTests(_TempDb):
    def test_grades_are_separate_histories_for_the_same_day(self):
        db.add_price("a", "2026-01-01", 10, source="manual")                      # Raw by default
        db.add_price("a", "2026-01-01", 55, source="manual", grade="PSA 10")
        db.add_price("a", "2026-01-01", 25, source="manual", grade="psa 9")       # spelling is normalized
        self.assertEqual(db.get_price_history("a").iloc[-1, 0], 10)
        self.assertEqual(db.get_price_history("a", grade="PSA 10").iloc[-1, 0], 55)
        self.assertEqual(db.get_price_history("a", grade="PSA 9").iloc[-1, 0], 25)
        self.assertEqual(db.get_grade_summary("a").grade.tolist(), ["Raw", "PSA 10", "PSA 9"])

    def test_same_day_same_grade_overwrites(self):
        db.add_price("a", "2026-01-01", 10, grade="PSA 10")
        db.add_price("a", "2026-01-01", 12, grade="PSA 10")
        self.assertEqual(len(db.get_price_history("a", grade="PSA 10")), 1)
        self.assertEqual(db.get_price_history("a", grade="PSA 10").iloc[-1, 0], 12)

    def test_unknown_grade_is_rejected(self):
        for call in (lambda: db.add_price("a", "2026-01-01", 10, grade="PSA 11"),
                     lambda: db.get_price_history("a", grade="Mint-ish"),
                     lambda: db.add_prices_bulk("a", [("2026-01-01", 10, None)], grade="nope")):
            with self.assertRaises(ValueError):
                call()

    def test_old_database_prices_become_raw(self):
        path = os.path.join(self.temp.name, "pregrade.db")
        with closing(sqlite3.connect(path)) as conn:
            conn.executescript(
                "CREATE TABLE cards(card_id TEXT PRIMARY KEY,name TEXT NOT NULL,set_name TEXT NOT NULL,rarity TEXT NOT NULL,"
                "base_price REAL NOT NULL,api_id TEXT,variant TEXT,image_url TEXT);"
                "CREATE TABLE prices(card_id TEXT NOT NULL,price_date TEXT NOT NULL,market_price REAL NOT NULL,volume INTEGER,"
                "psa10_multiplier REAL,catalyst_flag INTEGER NOT NULL DEFAULT 0,source TEXT NOT NULL DEFAULT 'mock',"
                "PRIMARY KEY(card_id,price_date));"
                "INSERT INTO cards VALUES('old','Old','S','R',1,NULL,NULL,NULL);"
                "INSERT INTO prices VALUES('old','2026-01-01',5,NULL,NULL,0,'csv');")
        with patch.object(db, "DB_PATH", path):
            db._checked_paths.discard(path)
            hist = db.get_price_history("old")
            self.assertEqual((len(hist), hist.iloc[0, 0]), (1, 5))
            self.assertEqual(db.get_card_sources("old", "Raw"), (1, {"csv"}))
            db.add_price("old", "2026-01-01", 50, grade="PSA 10")          # same date, new grade: now allowed

    def test_csv_import_replaces_mock_only_for_its_own_grade(self):
        db.add_price("a", "2026-01-01", 10, source="mock")
        db.add_price("a", "2026-01-01", 50, source="mock", grade="PSA 10")
        rows = pd.DataFrame({"date": ["2026-01-02"], "price": [60]})
        self.assertEqual(ps.import_csv("a", rows, grade="PSA 10"), (1, 1))
        self.assertEqual(db.get_card_sources("a", "Raw"), (1, {"mock"}))        # Raw untouched
        self.assertEqual(db.get_card_sources("a", "PSA 10"), (1, {"csv"}))

    def test_real_card_link_clears_made_up_prices_in_every_grade(self):
        db.add_price("a", "2026-01-01", 10, source="mock")
        db.add_price("a", "2026-01-01", 50, source="mock", grade="PSA 10")
        db.link_real_card("a", "base1-4", "Charizard", "Base", "Rare", "holofoil")
        self.assertEqual(db.get_card_sources("a"), (0, set()))

    def test_refresh_only_touches_raw_prices(self):
        card = {"id": "base1-4", "name": "Charizard", "set": {"name": "Base"}, "tcgplayer": {"prices": {"holofoil": {"market": 100}}}}
        cid, _, _ = ps.save_card_with_price(card, "holofoil")
        db.add_price(cid, "2026-01-01", 900, source="manual", grade="PSA 10")
        ps.refresh_tracked_cards(Mock(get_card=Mock(return_value=card)))
        self.assertEqual(db.get_price_history(cid, grade="PSA 10").iloc[-1, 0], 900)
        self.assertEqual(db.get_price_history(cid).iloc[-1, 0], 100)

    def test_premium_is_relative_to_raw(self):
        s = pd.DataFrame({"grade": ["Raw", "PSA 10"], "last_price": [20.0, 100.0]})
        self.assertEqual(grading.add_premium(s)["premium"].tolist(), [1.0, 5.0])
        self.assertTrue(grading.add_premium(s.iloc[1:])["premium"].isna().all())      # no Raw price -> no premium

    # ---- demo data
    def test_seeded_cards_have_every_demo_grade_and_are_repeatable(self):
        data_generator.seed_database()
        self.assertEqual(db.get_grade_summary("charizard_holo").grade.tolist(),
                         ["Raw", "PSA 10", "PSA 9", "PSA 8", "BGS 9.5", "CGC 10"])
        first = db.get_price_history("charizard_holo", grade="PSA 10").iloc[:, 0].tolist()
        data_generator.seed_database()
        self.assertEqual(first, db.get_price_history("charizard_holo", grade="PSA 10").iloc[:, 0].tolist())

    def test_better_grades_cost_more_on_average(self):
        data_generator.seed_database()
        mean = lambda g: db.get_price_history("charizard_holo", grade=g).iloc[:, 0].mean()
        self.assertGreater(mean("PSA 10"), mean("PSA 9"))
        self.assertGreater(mean("PSA 9"), mean("Raw"))

    def test_backfill_only_touches_pure_demo_cards_without_grades(self):
        db.add_price("a", "2026-01-01", 10, source="mock")                          # demo card, Raw only
        for i in range(3):
            db.add_price("a", f"2026-01-0{i + 2}", 10 + i, source="mock")
        db.add_price("b", "2026-01-01", 10, source="csv")                            # real card
        self.assertEqual(data_generator.backfill_demo_grades(), 1)
        self.assertGreater(len(db.get_grade_summary("a")), 1)
        self.assertEqual(db.get_grade_summary("b").grade.tolist(), ["Raw"])
        self.assertEqual(data_generator.backfill_demo_grades(), 0)                   # nothing left to do


class RemoveCardTests(_TempDb):
    def test_removing_a_card_deletes_all_its_prices_in_every_grade(self):
        db.add_price("a", "2026-01-01", 10)
        db.add_price("a", "2026-01-01", 50, grade="PSA 10")
        db.add_price("b", "2026-01-01", 7)
        self.assertEqual(db.delete_card("a"), {"cards": 1, "prices": 2})
        self.assertIsNone(db.get_card("a"))
        self.assertEqual(db.get_card_sources("a"), (0, set()))
        self.assertEqual(db.list_cards().card_id.tolist(), ["b"])
        self.assertEqual(db.get_price_history("b").iloc[-1, 0], 7)              # other cards untouched

    def test_removing_a_missing_card_is_harmless(self):
        self.assertEqual(db.delete_card("nope"), {"cards": 0, "prices": 0})
        self.assertEqual(len(db.list_cards()), 2)

    def test_removed_card_can_be_added_again_cleanly(self):
        db.add_price("a", "2026-01-01", 10)
        db.delete_card("a")
        db.upsert_card("a", "Card A", "Set", "Rare", 10)
        self.assertTrue(db.get_price_history("a").empty)

    def test_emptied_database_is_not_reseeded(self):
        data_generator.seed_database()
        for cid in db.list_cards().card_id:
            db.delete_card(cid)
        db.initialize_database()
        self.assertTrue(db.list_cards().empty)


if __name__ == "__main__":
    unittest.main()
