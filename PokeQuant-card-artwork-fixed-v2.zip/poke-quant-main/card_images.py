import re
import requests
import streamlit as st

# TCGdex provides a public card catalog and CDN. Unlike the old Pokémon TCG API,
# it does not require an API key. The CDN URL format is documented at tcgdex.dev.
TCGDEX_API = "https://api.tcgdex.net/v2/en/cards"
TCGDEX_ASSETS = "https://assets.tcgdex.net/en"

# The demo database intentionally uses friendly / made-up display names rather
# than exact TCG catalog names. These IDs connect those demo cards to real cards.
DEMO_CARD_IDS = {
    "charizard_holo": "base1-4",
    "blastoise_holo": "base1-2",
    "venusaur_holo": "base1-15",
    "pikachu_promo": "basep-1",
    "mewtwo_holo": "base1-10",
    "gengar_holo": "fossil-5",
    "dragonite_holo": "fossil-4",
    "lugia_holo": "neo1-9",
    "umbreon_alt_art": "swsh7-215",
    "rayquaza_vmax": "swsh7-111",
    "mew_ex": "sv4pt5-053",
    "gyarados_holo": "base1-6",
}


def _tcgdex_image(card_id):
    """Return a real card image from the TCGdex CDN for a TCGdex card id."""
    if not card_id or "-" not in card_id:
        return None
    set_id, local_id = card_id.split("-", 1)

    # TCGdex separates the series from the set in its asset path. For the
    # common sets below, this is enough to build a stable image URL.
    series = {
        "base1": "base",
        "basep": "base",
        "fossil": "base",
        "neo1": "neo",
        "swsh7": "swsh",
        "sv4pt5": "sv",
    }.get(set_id)
    if not series:
        return None

    return f"{TCGDEX_ASSETS}/{series}/{set_id}/{local_id}/high.webp"


@st.cache_data(ttl=86400, show_spinner=False)
def find_card_image(name, set_name, card_id=None):
    """Find artwork for seeded cards or cards added through the database UI."""
    # 1. Exact mapping for seeded/demo cards.
    if card_id in DEMO_CARD_IDS:
        image = _tcgdex_image(DEMO_CARD_IDS[card_id])
        if image:
            return image

    # 2. TCGdex REST filters use `name=...`; `q=...` is not a supported
    # filter and can silently return unrelated cards or no useful results.
    # Database display names sometimes include labels such as "Holo" or
    # "Alt Art", so try both the full name and a cleaned Pokémon/card name.
    raw_name = (name or "").strip()
    cleaned_name = re.sub(
        r"\s+(holo|holo rare|reverse holo|alt art|alternate art|full art|\(.*?\))$",
        "", raw_name, flags=re.IGNORECASE,
    ).strip()
    search_names = []
    for candidate in (raw_name, cleaned_name):
        if candidate and candidate.casefold() not in [n.casefold() for n in search_names]:
            search_names.append(candidate)

    for search_name in search_names:
        try:
            response = requests.get(
                TCGDEX_API,
                params={"name": search_name, "pagination:itemsPerPage": 100},
                timeout=10,
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, dict):
                data = data.get("cards", data.get("data", []))
            if not isinstance(data, list) or not data:
                continue

            # List results are CardBrief records; set metadata may be absent.
            # Prefer an exact card-name match, then use the first image result.
            candidates = [c for c in data if isinstance(c, dict) and c.get("image")]
            if not candidates:
                continue
            exact = [c for c in candidates if str(c.get("name", "")).casefold() == cleaned_name.casefold()]
            chosen = exact[0] if exact else candidates[0]
            image_base = chosen.get("image")
            if image_base:
                return image_base.rstrip("/") + "/high.webp"
        except (requests.RequestException, ValueError, TypeError):
            continue

    # 3. If a database row's ID is already a TCGdex ID (for example base1-4),
    # use it directly as a final fallback.
    if card_id and "-" in str(card_id):
        try:
            response = requests.get(f"{TCGDEX_API}/{card_id}", timeout=8)
            if response.ok:
                card = response.json()
                image_base = card.get("image") if isinstance(card, dict) else None
                if image_base:
                    return image_base.rstrip("/") + "/high.webp"
        except (requests.RequestException, ValueError, TypeError):
            pass

    return None
